The goal of this project is to be an up-to-date, open, easily machine-processible repository of soccer results.
